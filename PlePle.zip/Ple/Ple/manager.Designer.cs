﻿namespace Ple
{
    partial class manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            exit = new Button();
            databaseE = new DataGridView();
            label1 = new Label();
            tab = new TabControl();
            Главная = new TabPage();
            deleteSmth = new Button();
            buttonAdd = new Button();
            label13 = new Label();
            label12 = new Label();
            textProductsDessert = new TextBox();
            textquantityDess = new TextBox();
            textProductsDrink = new TextBox();
            textNameDess = new TextBox();
            textdescriptionD = new TextBox();
            textquantityD = new TextBox();
            textdescriptionDess = new TextBox();
            textNameD = new TextBox();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            comboBoxCategories = new ComboBox();
            exitT = new Button();
            databaseM = new DataGridView();
            Сотрудники = new TabPage();
            deleteE = new Button();
            label7 = new Label();
            label6 = new Label();
            textUsername = new TextBox();
            label5 = new Label();
            comboBoxE = new ComboBox();
            textSurname = new TextBox();
            label4 = new Label();
            textBoxCode = new TextBox();
            label3 = new Label();
            label2 = new Label();
            buttonLogin = new Button();
            ((System.ComponentModel.ISupportInitialize)databaseE).BeginInit();
            tab.SuspendLayout();
            Главная.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)databaseM).BeginInit();
            Сотрудники.SuspendLayout();
            SuspendLayout();
            // 
            // exit
            // 
            exit.BackColor = Color.Sienna;
            exit.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            exit.ForeColor = SystemColors.ControlLightLight;
            exit.Location = new Point(1005, 16);
            exit.Name = "exit";
            exit.Size = new Size(50, 49);
            exit.TabIndex = 0;
            exit.Text = "X";
            exit.UseVisualStyleBackColor = false;
            exit.Click += exit_Click_1;
            // 
            // databaseE
            // 
            databaseE.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            databaseE.BackgroundColor = SystemColors.ControlLightLight;
            databaseE.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            databaseE.Location = new Point(291, 34);
            databaseE.Name = "databaseE";
            databaseE.RowHeadersWidth = 51;
            databaseE.Size = new Size(581, 233);
            databaseE.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(32, 25);
            label1.Name = "label1";
            label1.Size = new Size(125, 31);
            label1.TabIndex = 3;
            label1.Text = "Просмотр:";
            // 
            // tab
            // 
            tab.Controls.Add(Главная);
            tab.Controls.Add(Сотрудники);
            tab.Dock = DockStyle.Right;
            tab.Location = new Point(-4, 0);
            tab.Name = "tab";
            tab.SelectedIndex = 0;
            tab.Size = new Size(1073, 559);
            tab.TabIndex = 4;
            // 
            // Главная
            // 
            Главная.BackColor = Color.Tan;
            Главная.Controls.Add(deleteSmth);
            Главная.Controls.Add(buttonAdd);
            Главная.Controls.Add(label13);
            Главная.Controls.Add(label12);
            Главная.Controls.Add(textProductsDessert);
            Главная.Controls.Add(textquantityDess);
            Главная.Controls.Add(textProductsDrink);
            Главная.Controls.Add(textNameDess);
            Главная.Controls.Add(textdescriptionD);
            Главная.Controls.Add(textquantityD);
            Главная.Controls.Add(textdescriptionDess);
            Главная.Controls.Add(textNameD);
            Главная.Controls.Add(label11);
            Главная.Controls.Add(label10);
            Главная.Controls.Add(label9);
            Главная.Controls.Add(label8);
            Главная.Controls.Add(label1);
            Главная.Controls.Add(comboBoxCategories);
            Главная.Controls.Add(exitT);
            Главная.Controls.Add(databaseM);
            Главная.ForeColor = Color.Black;
            Главная.Location = new Point(4, 29);
            Главная.Name = "Главная";
            Главная.Padding = new Padding(3);
            Главная.Size = new Size(1065, 526);
            Главная.TabIndex = 0;
            Главная.Text = "Главная";
            // 
            // deleteSmth
            // 
            deleteSmth.BackColor = Color.Sienna;
            deleteSmth.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            deleteSmth.ForeColor = SystemColors.ControlLightLight;
            deleteSmth.Location = new Point(784, 370);
            deleteSmth.Name = "deleteSmth";
            deleteSmth.Size = new Size(142, 35);
            deleteSmth.TabIndex = 19;
            deleteSmth.Text = "Удалить";
            deleteSmth.UseVisualStyleBackColor = false;
            deleteSmth.Click += deleteSmth_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.BackColor = Color.Sienna;
            buttonAdd.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            buttonAdd.ForeColor = SystemColors.ControlLightLight;
            buttonAdd.Location = new Point(784, 311);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(142, 38);
            buttonAdd.TabIndex = 18;
            buttonAdd.Text = "Добавить";
            buttonAdd.UseVisualStyleBackColor = false;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label13.Location = new Point(512, 290);
            label13.Name = "label13";
            label13.Size = new Size(236, 28);
            label13.TabIndex = 17;
            label13.Text = "Описание/Ингредиенты";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label12.Location = new Point(337, 290);
            label12.Name = "label12";
            label12.Size = new Size(151, 28);
            label12.TabIndex = 16;
            label12.Text = "Наименование";
            // 
            // textProductsDessert
            // 
            textProductsDessert.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textProductsDessert.Location = new Point(322, 461);
            textProductsDessert.Multiline = true;
            textProductsDessert.Name = "textProductsDessert";
            textProductsDessert.Size = new Size(166, 34);
            textProductsDessert.TabIndex = 15;
            // 
            // textquantityDess
            // 
            textquantityDess.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textquantityDess.Location = new Point(543, 461);
            textquantityDess.Multiline = true;
            textquantityDess.Name = "textquantityDess";
            textquantityDess.Size = new Size(166, 34);
            textquantityDess.TabIndex = 14;
            // 
            // textProductsDrink
            // 
            textProductsDrink.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textProductsDrink.Location = new Point(322, 367);
            textProductsDrink.Multiline = true;
            textProductsDrink.Name = "textProductsDrink";
            textProductsDrink.Size = new Size(166, 34);
            textProductsDrink.TabIndex = 13;
            // 
            // textNameDess
            // 
            textNameDess.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textNameDess.Location = new Point(322, 416);
            textNameDess.Multiline = true;
            textNameDess.Name = "textNameDess";
            textNameDess.Size = new Size(166, 34);
            textNameDess.TabIndex = 12;
            // 
            // textdescriptionD
            // 
            textdescriptionD.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textdescriptionD.Location = new Point(543, 313);
            textdescriptionD.Multiline = true;
            textdescriptionD.Name = "textdescriptionD";
            textdescriptionD.Size = new Size(166, 34);
            textdescriptionD.TabIndex = 11;
            // 
            // textquantityD
            // 
            textquantityD.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textquantityD.Location = new Point(543, 367);
            textquantityD.Multiline = true;
            textquantityD.Name = "textquantityD";
            textquantityD.Size = new Size(166, 34);
            textquantityD.TabIndex = 10;
            // 
            // textdescriptionDess
            // 
            textdescriptionDess.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textdescriptionDess.Location = new Point(543, 413);
            textdescriptionDess.Multiline = true;
            textdescriptionDess.Name = "textdescriptionDess";
            textdescriptionDess.Size = new Size(166, 34);
            textdescriptionDess.TabIndex = 9;
            // 
            // textNameD
            // 
            textNameD.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textNameD.Location = new Point(322, 316);
            textNameD.Multiline = true;
            textNameD.Name = "textNameD";
            textNameD.Size = new Size(166, 34);
            textNameD.TabIndex = 8;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 204);
            label11.Location = new Point(32, 464);
            label11.Name = "label11";
            label11.Size = new Size(246, 28);
            label11.TabIndex = 7;
            label11.Text = "Добавить ТТК десерты:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 204);
            label10.Location = new Point(32, 370);
            label10.Name = "label10";
            label10.Size = new Size(249, 28);
            label10.TabIndex = 6;
            label10.Text = "Добавить ТТК напитки:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 204);
            label9.Location = new Point(32, 416);
            label9.Name = "label9";
            label9.Size = new Size(191, 28);
            label9.TabIndex = 5;
            label9.Text = "Добавить десерт:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 204);
            label8.Location = new Point(32, 327);
            label8.Name = "label8";
            label8.Size = new Size(208, 28);
            label8.TabIndex = 4;
            label8.Text = "Добавить напиток:";
            // 
            // comboBoxCategories
            // 
            comboBoxCategories.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            comboBoxCategories.FormattingEnabled = true;
            comboBoxCategories.Location = new Point(32, 59);
            comboBoxCategories.Name = "comboBoxCategories";
            comboBoxCategories.Size = new Size(179, 36);
            comboBoxCategories.TabIndex = 2;
            comboBoxCategories.SelectedIndexChanged += comboBoxCategories_SelectedIndexChanged;
            // 
            // exitT
            // 
            exitT.BackColor = Color.Sienna;
            exitT.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            exitT.ForeColor = SystemColors.ControlLightLight;
            exitT.Location = new Point(1002, 15);
            exitT.Name = "exitT";
            exitT.Size = new Size(55, 48);
            exitT.TabIndex = 1;
            exitT.Text = "Х";
            exitT.UseVisualStyleBackColor = false;
            exitT.Click += button1_Click;
            // 
            // databaseM
            // 
            databaseM.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            databaseM.BackgroundColor = SystemColors.ControlLightLight;
            databaseM.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            databaseM.Location = new Point(284, 33);
            databaseM.Name = "databaseM";
            databaseM.RowHeadersWidth = 51;
            databaseM.Size = new Size(594, 238);
            databaseM.TabIndex = 0;
            // 
            // Сотрудники
            // 
            Сотрудники.BackColor = Color.Tan;
            Сотрудники.Controls.Add(deleteE);
            Сотрудники.Controls.Add(label7);
            Сотрудники.Controls.Add(label6);
            Сотрудники.Controls.Add(textUsername);
            Сотрудники.Controls.Add(label5);
            Сотрудники.Controls.Add(comboBoxE);
            Сотрудники.Controls.Add(textSurname);
            Сотрудники.Controls.Add(label4);
            Сотрудники.Controls.Add(textBoxCode);
            Сотрудники.Controls.Add(exit);
            Сотрудники.Controls.Add(label3);
            Сотрудники.Controls.Add(label2);
            Сотрудники.Controls.Add(databaseE);
            Сотрудники.Controls.Add(buttonLogin);
            Сотрудники.Location = new Point(4, 29);
            Сотрудники.Name = "Сотрудники";
            Сотрудники.Padding = new Padding(3);
            Сотрудники.Size = new Size(1065, 526);
            Сотрудники.TabIndex = 1;
            Сотрудники.Text = "Сотрудники";
            // 
            // deleteE
            // 
            deleteE.BackColor = Color.Sienna;
            deleteE.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            deleteE.ForeColor = SystemColors.ControlLightLight;
            deleteE.Location = new Point(291, 407);
            deleteE.Name = "deleteE";
            deleteE.Size = new Size(173, 35);
            deleteE.TabIndex = 11;
            deleteE.Text = "Удалить";
            deleteE.UseVisualStyleBackColor = false;
            deleteE.Click += deleteE_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 204);
            label7.Location = new Point(35, 414);
            label7.Name = "label7";
            label7.Size = new Size(226, 28);
            label7.TabIndex = 10;
            label7.Text = "Удаление сотрудника:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label6.Location = new Point(35, 34);
            label6.Name = "label6";
            label6.Size = new Size(125, 31);
            label6.TabIndex = 9;
            label6.Text = "Просмотр:";
            // 
            // textUsername
            // 
            textUsername.Location = new Point(724, 333);
            textUsername.Multiline = true;
            textUsername.Name = "textUsername";
            textUsername.Size = new Size(173, 34);
            textUsername.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label5.Location = new Point(724, 305);
            label5.Name = "label5";
            label5.Size = new Size(174, 25);
            label5.TabIndex = 7;
            label5.Text = "Введите должность:";
            // 
            // comboBoxE
            // 
            comboBoxE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            comboBoxE.FormattingEnabled = true;
            comboBoxE.Location = new Point(35, 68);
            comboBoxE.Name = "comboBoxE";
            comboBoxE.Size = new Size(173, 36);
            comboBoxE.TabIndex = 6;
            comboBoxE.SelectedIndexChanged += comboBoxE_SelectedIndexChanged;
            // 
            // textSurname
            // 
            textSurname.Location = new Point(519, 333);
            textSurname.Multiline = true;
            textSurname.Name = "textSurname";
            textSurname.Size = new Size(173, 34);
            textSurname.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.Location = new Point(519, 305);
            label4.Name = "label4";
            label4.Size = new Size(164, 25);
            label4.TabIndex = 4;
            label4.Text = "Введите фамилию:";
            // 
            // textBoxCode
            // 
            textBoxCode.Location = new Point(291, 333);
            textBoxCode.Multiline = true;
            textBoxCode.Name = "textBoxCode";
            textBoxCode.Size = new Size(173, 34);
            textBoxCode.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.Location = new Point(313, 305);
            label3.Name = "label3";
            label3.Size = new Size(116, 25);
            label3.TabIndex = 2;
            label3.Text = "Введите код:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 204);
            label2.Location = new Point(35, 333);
            label2.Name = "label2";
            label2.Size = new Size(237, 28);
            label2.TabIndex = 1;
            label2.Text = "Добавить сотрудника:";
            // 
            // buttonLogin
            // 
            buttonLogin.BackColor = Color.Sienna;
            buttonLogin.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            buttonLogin.ForeColor = SystemColors.ControlLightLight;
            buttonLogin.Location = new Point(919, 333);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(126, 35);
            buttonLogin.TabIndex = 0;
            buttonLogin.Text = "Добавить";
            buttonLogin.UseVisualStyleBackColor = false;
            buttonLogin.Click += buttonLogin_Click;
            // 
            // manager
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1069, 559);
            Controls.Add(tab);
            Name = "manager";
            Text = "manager";
            ((System.ComponentModel.ISupportInitialize)databaseE).EndInit();
            tab.ResumeLayout(false);
            Главная.ResumeLayout(false);
            Главная.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)databaseM).EndInit();
            Сотрудники.ResumeLayout(false);
            Сотрудники.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button exit;
        private DataGridView databaseE;
        private Label label1;
        private TabControl tab;
        private TabPage Главная;
        private TabPage Сотрудники;
        private TabPage tabPage1;
        private Label label3;
        private Label label2;
        private Button buttonLogin;
        private Button exitT;
        private DataGridView databaseM;
        private TextBox textSurname;
        private Label label4;
        private TextBox textBoxCode;
        private ComboBox comboBoxCategories;
        private ComboBox comboBoxE;
        private TextBox textUsername;
        private Label label5;
        private Button deleteE;
        private Label label7;
        private Label label6;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private TextBox textProductsDessert;
        private TextBox textquantityDess;
        private TextBox textProductsDrink;
        private TextBox textNameDess;
        private TextBox textdescriptionD;
        private TextBox textquantityD;
        private TextBox textdescriptionDess;
        private TextBox textNameD;
        private Button deleteSmth;
        private Button buttonAdd;
        private Label label13;
        private Label label12;
        private Button update1;
    }
}