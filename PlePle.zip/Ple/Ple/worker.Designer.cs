﻿namespace Ple
{
    partial class worker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            databaseW = new DataGridView();
            comboBoxCategories = new ComboBox();
            Просмотр = new Label();
            ((System.ComponentModel.ISupportInitialize)databaseW).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Sienna;
            button1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(910, 12);
            button1.Name = "button1";
            button1.Size = new Size(146, 53);
            button1.TabIndex = 0;
            button1.Text = "Выйти";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // databaseW
            // 
            databaseW.AllowUserToAddRows = false;
            databaseW.AllowUserToDeleteRows = false;
            databaseW.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            databaseW.BackgroundColor = SystemColors.ControlLightLight;
            databaseW.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            databaseW.Location = new Point(260, 93);
            databaseW.Name = "databaseW";
            databaseW.ReadOnly = true;
            databaseW.RowHeadersWidth = 51;
            databaseW.Size = new Size(577, 310);
            databaseW.TabIndex = 1;
            // 
            // comboBoxCategories
            // 
            comboBoxCategories.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            comboBoxCategories.FormattingEnabled = true;
            comboBoxCategories.Items.AddRange(new object[] { "Напитки", "Десерты", "Чек-листы" });
            comboBoxCategories.Location = new Point(32, 116);
            comboBoxCategories.Name = "comboBoxCategories";
            comboBoxCategories.Size = new Size(181, 36);
            comboBoxCategories.TabIndex = 2;
            comboBoxCategories.SelectedIndexChanged += comboBoxCategories_SelectedIndexChanged;
            // 
            // Просмотр
            // 
            Просмотр.AutoSize = true;
            Просмотр.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Просмотр.Location = new Point(32, 82);
            Просмотр.Name = "Просмотр";
            Просмотр.Size = new Size(125, 31);
            Просмотр.TabIndex = 3;
            Просмотр.Text = "Просмотр:";
            // 
            // worker
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Tan;
            ClientSize = new Size(1068, 573);
            Controls.Add(Просмотр);
            Controls.Add(comboBoxCategories);
            Controls.Add(databaseW);
            Controls.Add(button1);
            Name = "worker";
            Text = " ";
            ((System.ComponentModel.ISupportInitialize)databaseW).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private DataGridView databaseW;
        private ComboBox comboBoxCategories;
        private Label Просмотр;
    }
}